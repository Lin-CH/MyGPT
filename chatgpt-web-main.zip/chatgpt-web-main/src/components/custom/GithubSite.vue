<template>
  <div class="text-neutral-400">
    <span>Star on</span>
    <a href="https://github.com/Chanzhaoyu/chatgpt-bot" target="_blank" class="text-blue-500">
      GitHub
    </a>
  </div>
</template>
